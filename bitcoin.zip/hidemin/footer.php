			</div>
			


<div id="footer">

<div id="copyright">
				CVVBASE.ME<br/>
				<?php
				$mtime = explode(' ', microtime());
				$totaltime = $mtime[0] + $mtime[1] - $starttime;
				printf('Page loaded in %.3f seconds.', $totaltime);
				?>
			</div>
				If you are capable of providing high quality Cards, Fulls, Dumps, you could possibly become a reseller.<br>
                                  Icq: 693050504<br>
				Page loaded in 0.004 seconds.			</div>


		</div>
	</body>
</html>
<?php
	$db->close();
?>