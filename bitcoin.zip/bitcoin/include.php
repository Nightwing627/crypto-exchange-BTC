<?php

$blockchain_root = "https://blockchain.info/";
$blockchain_receive_root = "https://api.blockchain.info/";
$mysite_root = "www.procc.store/work/bitcoin/";
$secret = "abc";
$my_xpub = "1DAFwaojrsaSuCmSHKtnzSKsHduPttAFge";
$my_api_key = "1DAFwaojrsaSuCmSHKtnzSKsHduPttAFge";

//Database
$mysql_host = 'http://www.procc.store/';
$mysql_username = 'proccuser';
$mysql_password = 'root';
$mysql_database = 'Asdqwe12#';

?>